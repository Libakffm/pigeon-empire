/* Pigeon Empire: self-contained 3D city renderer, WebGL without external libraries. */
(()=>{'use strict';
let staticVerts=[],lastPeopleTick=-1;
let pedestrians=[],attack=null,selectedHuman=-1,attackMode=false;
let camera={yaw:.65,pitch:.88,dist:40,cx:0,cz:0},gl=null,canvas=null,program=null,buffer=null,verts=[],placeCenters=[],placeBounds=[],frame=0;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const sites=[[-18,-18],[0,-18],[18,-18],[18,0],[0,18],[-18,0],[0,0],[18,18]];
const palettes=[[.24,.65,.45],[.93,.63,.32],[.43,.64,.86],[.89,.48,.65],[.72,.68,.9],[.55,.79,.52],[.94,.72,.40],[.96,.57,.28]];
function triangle(a,b,c,col){for(const p of [a,b,c])verts.push(...p,...col)}
function quad(a,b,c,d,col){triangle(a,b,c,col);triangle(a,c,d,col)}
function box(x,y,z,w,h,d,col){const x0=x-w/2,x1=x+w/2,y0=y,y1=y+h,z0=z-d/2,z1=z+d/2;const p=[ [x0,y0,z0],[x1,y0,z0],[x1,y0,z1],[x0,y0,z1],[x0,y1,z0],[x1,y1,z0],[x1,y1,z1],[x0,y1,z1]];const shade=k=>col.map(v=>v*k);quad(p[4],p[5],p[6],p[7],shade(1.15));quad(p[0],p[1],p[5],p[4],shade(.86));quad(p[1],p[2],p[6],p[5],shade(.76));quad(p[2],p[3],p[7],p[6],shade(.94));quad(p[3],p[0],p[4],p[7],shade(.7));}
function tree(x,z,s=1){
 box(x,0,z,.24,1.65*s,.24,[.39,.29,.2]);
 box(x,1.05*s,z,1.35*s,1.05*s,1.35*s,[.22,.49,.29]);
 box(x-.32*s,1.65*s,z+.2*s,1.08*s,.9*s,1.08*s,[.26,.59,.32]);
 box(x+.3*s,1.8*s,z-.22*s,1.04*s,.88*s,1.04*s,[.31,.63,.36]);
}
// Animated actors are assembled in local coordinates, then rotated around Y.
// This makes the face, feet and arms follow the actual direction of travel.
let actor=null;
function actorBox(x,y,z,w,h,d,col){
 if(!actor){box(x,y,z,w,h,d,col);return;}
 const {x:ox,y:oy,z:oz,angle}=actor,ca=Math.cos(angle),sa=Math.sin(angle);
 // Transform every vertex, not merely the box center: limbs and body rotate together.
 const start=verts.length;box(x,y,z,w,h,d,col);
 for(let i=start;i<verts.length;i+=6){const px=verts[i],pz=verts[i+2];verts[i]=ox+px*ca+pz*sa;verts[i+1]=oy+verts[i+1];verts[i+2]=oz-px*sa+pz*ca;}
}
function person(x,z,t=0,time=0,heading=0,speed=1,reaction=null){
 const shirt=[[.75,.29,.28],[.23,.47,.76],[.84,.59,.2],[.52,.36,.65],[.22,.58,.49]][t%5];
 const skin=[[.91,.67,.48],[.65,.43,.3],[.98,.78,.59],[.48,.32,.24]][t%4];
 const phase=time*(5.2+speed*2)+t*1.7,stride=Math.sin(phase)*.22;
 const r=reaction,active=!!r&&r.elapsed>=0&&r.elapsed<3.3;
 const elapsed=active?r.elapsed:0,kind=active?r.kind:-1;
 // Every response has a distinct full-body silhouette and a short recovery.
 const intensity=active?Math.min(1,elapsed/.17,Math.max(0,(3.3-elapsed)/.65)):0;
 const shock=kind===0?intensity:0,anger=kind===1?intensity:0;
 const fleeing=kind===2?intensity:0,confused=kind===3?intensity:0;
 const hop=shock*Math.pow(Math.max(0,Math.sin(elapsed*9.5)),2)*.56;
 const crouch=shock*(elapsed<.23?.16:0);
 const stomp=anger*Math.abs(Math.sin(elapsed*10))*.075;
 const bob=Math.abs(Math.sin(phase))*.035*(1-confused)+hop+stomp-crouch;
 const motion=confused?0:fleeing?Math.sin(phase*2.1)*.36:stride;
 const torsoSway=Math.sin(phase)*.035+anger*Math.sin(elapsed*12)*.19+confused*Math.sin(elapsed*3.4)*.14;
 const torsoTwist=anger*Math.sin(elapsed*8)*.28+confused*Math.sin(elapsed*2.8)*.48;
 actor={x,y:bob,z,angle:heading+torsoTwist};
 // Shock: feet kick outward; anger: one foot stomps; confusion: feet freeze.
 actorBox(-.12-shock*.085,0,motion+shock*.12,.15,.52,.18,[.24,.29,.37]);
 actorBox(.12+shock*.085,0,-motion-shock*.12,.15,.52,.18,[.24,.29,.37]);
 actorBox(torsoSway,.53,shock*.08,.44,.68,.29,shirt);
 // Arms visibly change position: raised in alarm, waving during anger, hands on head when confused.
 if(shock>.01){
  actorBox(-.42,1.00+shock*.23,-.12,.14,.53,.16,skin);
  actorBox(.42,1.00+shock*.23,-.12,.14,.53,.16,skin);
 }else if(anger>.01){
  const wave=Math.sin(elapsed*15);
  actorBox(-.37-anger*.13,.86+anger*(.34+.23*wave),-.18,.14,.54,.16,skin);
  actorBox(.37+anger*.13,.86+anger*(.34-.23*wave),-.18,.14,.54,.16,skin);
 }else if(confused>.01){
  actorBox(-.28,.93+confused*.30,-.18,.13,.52,.16,skin);
  actorBox(.28,.93+confused*.30,-.18,.13,.52,.16,skin);
 }else{
  actorBox(-.32,.64,-motion*.8,.13,.54,.16,skin);
  actorBox(.32,.64,motion*.8,.13,.54,.16,skin);
 }
 const look=confused*Math.sin(elapsed*5)*.14;
 actorBox(torsoSway*.6+look,1.22,-.035,.34,.37,.33,skin);
 actorBox(torsoSway*.6+look,1.53,-.065,.38,.14,.37,[.24,.19,.16]);
 if(active){
  if(kind===0)actorBox(0,2.06,-.06,.24,.24,.10,[.99,.88,.25]);
  if(kind===1){actorBox(0,2.03,-.07,.32,.12,.12,[.94,.26,.24]);actorBox(0,2.18,-.07,.13,.13,.13,[.94,.26,.24]);}
  if(kind===2)actorBox(0,1.95,-.05,.22,.18,.10,[.98,.94,.89]);
  if(kind===3)actorBox(0,2.03,-.05,.25,.22,.10,[.55,.75,.99]);
 }
 actor=null;
}
function pigeon(x,z,time=0,heading=0,height=.08,flying=false,seed=0){
 const flap=Math.sin(time*(flying?13:7)+seed*2.1);
 actor={x,y:height,z,angle:heading};
 actorBox(0,.08,0,.42,.27,.54,[.53,.59,.66]);
 actorBox(0,.27,-.17,.27,.3,.26,[.62,.68,.74]);
 // Wing height and spread vary throughout the stroke.
 const wingLift=flying?flap*.22:flap*.045;
 const wingSpread=flying?.39+Math.abs(flap)*.17:.28;
 actorBox(-wingSpread,.18+wingLift,0,.30,.095,.37,[.43,.51,.61]);
 actorBox(wingSpread,.18+wingLift,0,.30,.095,.37,[.43,.51,.61]);
 actorBox(0,.38,-.35,.12,.085,.18,[.91,.61,.19]);
 actorBox(0,.13,.33,.24,.09,.24,[.44,.51,.6]);
 if(!flying){actorBox(-.12,-.04,.12,.05,.1,.12,[.83,.38,.31]);actorBox(.12,-.04,.12,.05,.1,.12,[.83,.38,.31]);}
 actor=null;
}
function lamp(x,z){box(x,0,z,.12,3.1,.12,[.29,.34,.37]);box(x,3.02,z,.42,.16,.42,[.25,.29,.32]);box(x,3.13,z,.34,.24,.34,[.98,.9,.64]);}
function bench(x,z){for(const dx of [-.65,.65])box(x+dx,0,z,.12,.52,.12,[.3,.32,.35]);box(x,.5,z,1.65,.15,.55,[.53,.34,.23]);box(x,.9,z-.23,1.65,.55,.12,[.57,.36,.24]);}
function makeScene(){verts=[];box(0,-.35,0,56,.35,56,[.43,.69,.45]);for(let k=-24;k<=24;k+=8){box(k,-.02,0,2.7,.025,56,[.40,.46,.49]);box(0,-.02,k,56,.025,2.7,[.40,.46,.49]);for(let q=-24;q<=24;q+=3.2){box(k,.015,q,.08,.018,1,[.94,.87,.61]);box(q,.015,k,1,.018,.08,[.94,.87,.61]);}}
// Light stone pavements, curb edges, zebra crossings and street furniture.
for(let k=-24;k<=24;k+=8){
 for(const offset of [-2.25,2.25]){
  box(k+offset,-.005,0,.85,.045,56,[.69,.69,.66]);
  box(0,-.005,k+offset,56,.045,.85,[.69,.69,.66]);
 }
 for(let m=-24;m<=24;m+=8){
  for(let q=-1;q<=1;q++){
   box(k+q*.67,.025,m+2.1,.38,.018,.58,[.92,.91,.84]);
   box(m+2.1,.025,k+q*.67,.58,.018,.38,[.92,.91,.84]);
  }
 }
}
for(const [x,z] of [[-22,-12],[-12,10],[12,-12],[12,10],[-12,-22],[22,12],[-22,22]])lamp(x,z);
for(const [x,z] of [[-14,16],[14,16],[-14,-6],[14,-6]])bench(x,z);
// deterministic neighborhoods, kept separate from interactive landmarks
for(let i=0;i<165;i++){const x=((i*17+11)%53)-26,z=((i*29+7)%53)-26;if(Math.abs(x%8)<2.8||Math.abs(z%8)<2.8||sites.some(s=>Math.hypot(s[0]-x,s[1]-z)<5.7))continue;const h=1+(i%6)*.36;const col=i%4===0?[.85,.76,.64]:i%4===1?[.75,.83,.78]:i%4===2?[.83,.72,.75]:[.71,.78,.84];box(x,0,z,1.9,h,1.8,col);box(x,h,z,2.15,.18,2.05,[.39,.49,.52]);
 box(x,h+.18,z,1.85,.12,1.7,[.46,.55,.57]);
 box(x-.5,0,z+.93,.46,.95,.07,[.37,.39,.41]);
 for(let y=1.12;y<h-.1;y+=.75){for(const dx of [-.48,.48]){
  box(x+dx,y,z+.94,.4,.38,.045,[.31,.53,.64]);
  box(x+dx,y+.22,z+.975,.44,.045,.06,[.92,.91,.84]);
 }}}
for(let i=0;i<125;i++){let x=((i*37+19)%550)/10-27,z=((i*71+31)%550)/10-27;if(Math.abs(x%8)<2.5||Math.abs(z%8)<2.5||sites.some(s=>Math.hypot(s[0]-x,s[1]-z)<4.5))continue;tree(x,z,.65+(i%4)*.14)}
placeCenters=[];placeBounds=[];
// Individuelle Wahrzeichen: Park, Markt, Bahnhof, Einkaufsstraße, Rathaus, Parkbank, Bäckerei, Pommesbude.
function roof(x,y,z,w,d,col){box(x,y,z,w,.35,d,col);box(x,y+.35,z,w*.76,.22,d*.75,col.map(c=>c*.86));}
function windowRow(x,z,y,w=3.2){for(const dx of [-w/3,0,w/3]){box(x+dx,y,z,.58,.68,.11,[.42,.73,.87]);box(x+dx,y+.53,z,.67,.09,.13,[.98,.95,.81]);}}
sites.forEach(([x,z],i)=>{
 const c=palettes[i];let h=3.4;
 if(i===0){ // Park: winding paved plaza, flower beds, fountain and trees
  box(x,0,z,6,.08,5.8,[.72,.82,.63]);box(x,.07,z,1,.08,5.8,[.93,.85,.68]);box(x,.07,z,6,.08,1,[.93,.85,.68]);
  for(const [dx,dz] of [[-2,-2],[2,-2],[-2,2],[2,2]])tree(x+dx,z+dz,.95);
  box(x,.1,z,1.9,.3,1.9,[.82,.81,.76]);box(x,.39,z,1.45,.22,1.45,[.32,.73,.9]);box(x,.61,z,.3,.9,.3,[.85,.86,.83]);
  pigeon(x-1.2,z+.7);pigeon(x+1.4,z-1);
  h=1.7;
 }else if(i===1){ // Market: stalls and awnings
  box(x,0,z,6,.08,5.8,[.85,.78,.62]);
  for(const dx of [-1.55,1.55]){box(x+dx,.12,z,2.5,1.2,2,[.95,.85,.65]);roof(x+dx,1.36,z,2.9,2.3,dx<0?[.94,.39,.35]:[.34,.68,.85]);box(x+dx,1.5,z+1.1,2.5,.25,.2,[.99,.94,.74]);}
  for(const dx of [-2,0,2])box(x+dx,.22,z+2,.5,.45,.5,[.86,.52,.27]);h=2.3;
 }else if(i===2){ // Station: terminal, platform and clock
  box(x,0,z,5.8,3.3,4.6,[.89,.84,.72]);roof(x,3.3,z,6.2,5.2,[.29,.51,.69]);
  windowRow(x,z+2.35,1.7,4.2);box(x,0,z+2.43,1.35,2.1,.13,[.32,.47,.6]);
  box(x,3.7,z,1.45,1.55,1.4,[.92,.82,.66]);box(x,2.85,z+2.47,5.6,.16,.14,[.97,.95,.86]);box(x,5.05,z+.73,.9,.9,.09,[.97,.96,.83]);
  box(x,5.5,z,1.65,.3,1.65,[.35,.49,.61]);
  for(const dx of [-2.8,2.8])box(x+dx,.08,z+3,.12,.08,6,[.46,.49,.51]);h=5.8;
 }else if(i===3){ // Shopping street: boutique with shopfront and striped canopy
  box(x,0,z,5.1,3.7,4.6,[.97,.78,.81]);roof(x,3.7,z,5.6,5,[.62,.38,.67]);
  windowRow(x,z+2.35,2.4);box(x,0,z+2.36,3.8,1.7,.15,[.38,.74,.84]);
  for(const dx of [-1.5,-.5,.5,1.5])box(x+dx,1.65,z+2.62,.48,.34,.52,dx%1===.5?[.95,.91,.86]:[.85,.42,.55]);
  box(x,3.1,z+2.5,3.4,.5,.15,[.99,.9,.65]);h=4.2;
 }else if(i===4){ // City hall: columns, clock tower, grand staircase
  box(x,0,z,6.8,4.7,5.1,[.93,.88,.75]);roof(x,4.7,z,7.3,5.7,[.43,.55,.68]);
  for(const dx of [-2.4,-1.2,0,1.2,2.4]){box(x+dx,.05,z+2.9,.35,3.7,.36,[.98,.96,.87]);box(x+dx,3.6,z+2.9,.6,.25,.6,[.89,.82,.69]);}
  box(x,0,z+3.3,6.8,.25,1.5,[.85,.83,.77]);for(const dx of [-2.8,2.8])box(x+dx,1.1,z+2.63,.35,.75,.12,[.36,.57,.68]);box(x,.25,z+3.9,5.5,.2,1,[.9,.88,.8]);
  box(x,5.05,z,2,2.7,2,[.92,.85,.69]);box(x,7.4,z,2.5,.55,2.5,[.38,.52,.66]);
  box(x,6.1,z+1.03,1.15,1.15,.12,[.99,.96,.83]);h=8;
 }else if(i===5){ // Park bench, lanterns, garden
  box(x,0,z,5.5,.08,5.3,[.75,.86,.67]);for(const dx of [-1.1,1.1]){box(x+dx,.36,z,.15,.8,.15,[.43,.33,.27]);box(x+dx,.85,z,.15,.8,.15,[.43,.33,.27]);}
  box(x,.8,z,3,.24,.8,[.65,.39,.23]);box(x,1.2,z-.3,3,.2,.25,[.65,.39,.23]);tree(x-2,z-1.7,.75);tree(x+2,z+1.6,.7);h=2;
 }else if(i===6){ // Bakery: cream walls, warm brick roof, bread-colored shop sign
  box(x,0,z,5.1,3.4,4.4,[.97,.87,.68]);roof(x,3.4,z,5.7,4.9,[.77,.36,.27]);
  box(x,0,z+2.28,3.7,1.9,.15,[.39,.7,.8]);box(x,0,z+2.42,.8,1.8,.1,[.39,.29,.24]);box(x,1.9,z+2.47,4.3,.55,.6,[.96,.64,.35]);
  box(x,2.65,z+2.32,3.4,.55,.12,[.72,.42,.24]);windowRow(x,z+2.3,2.9);h=4;
 }else{ // Fries stand: bright red-yellow striped canopy, serving counter and fries sign
  box(x,0,z,4.6,2.1,3.6,[.98,.79,.35]);box(x,1.15,z+1.88,3.5,.75,.13,[.35,.56,.59]);
  roof(x,2.1,z,5.4,4.2,[.93,.3,.28]);
  for(const dx of [-2,-1,0,1,2])box(x+dx,2.14,z+2.13,.55,.36,.17,dx%2?[.99,.86,.35]:[.95,.31,.27]);
  box(x,2.7,z,1.4,1.05,.24,[.98,.81,.28]);for(const dx of [-.4,-.15,.1,.35])box(x+dx,3.75,z,.15,.48,.15,[.99,.88,.45]);
  box(x,0,z+2.2,4.2,.8,.6,[.95,.58,.31]);box(x,1.17,z+1.98,3.3,.11,.11,[.94,.92,.83]);box(x-1.65,.85,z+2.45,.18,1.4,.18,[.75,.23,.21]);h=4.3;
 }
 placeCenters.push([x,h,z]);placeBounds.push({x,z,h:h+.6,w:i===4?7.6:6.2,d:i===4?7.3:6.3});
});
// Pedestrians and pigeons are animated separately on independent routes.

// Player headquarters: a growing natural, open twig nest, never a house.
const nestLevel=Math.max(1,Number(window.pigeonNestLevel?.()||1));
const nx=-19,nz=19,growth=Math.min(9,nestLevel-1);
const outer=1.48+growth*.19;
const twigDark=[.39,.23,.12],twigMid=[.57,.34,.17],twigLight=[.76,.51,.26];
const straw=[.87,.72,.42],lining=[.93,.82,.56];
// Natural planted clearing and a ring of stones make the nest visible in town.
box(nx,0,nz,8.6,.09,8.6,[.46,.69,.36]);
for(let k=0;k<15;k++){
 const a=k*Math.PI*2/15,r=outer+.75;
 box(nx+Math.cos(a)*r,.09,nz+Math.sin(a)*r,.44,.23,.43,k%3?[.59,.57,.49]:[.71,.68,.57]);
}
// Dense layered twig bowl, with an unobstructed straw-filled opening.
for(let ring=0;ring<4+Math.min(growth,4);ring++){
 const r=.40+ring*(outer-.36)/(3+Math.min(growth,4));
 const pieces=16+ring*6;
 for(let k=0;k<pieces;k++){
  const a=(k+.43*(ring%2))*Math.PI*2/pieces;
  box(nx+Math.cos(a)*r,.15+ring*.043,nz+Math.sin(a)*r,.54,.12,.19,(k+ring)%3===0?twigLight:(k%2?twigDark:twigMid));
 }
}
for(let layer=0;layer<3+Math.min(growth,5);layer++){
 const radius=outer-.065*layer,y=.27+layer*.14,pieces=28+growth*4;
 for(let k=0;k<pieces;k++){
  const a=k*Math.PI*2/pieces+layer*.16;
  box(nx+Math.cos(a)*radius,y,nz+Math.sin(a)*radius,.54,.13,.21,(k+layer)%4===0?twigLight:(k%2?twigMid:twigDark));
 }
}
box(nx,.40,nz,Math.max(1.5,outer*1.18),.10,Math.max(1.5,outer*1.18),lining);
for(let k=0;k<14+growth*3;k++){
 const a=k*2.399,r=.22+(k%5)*.16;
 box(nx+Math.cos(a)*r,.49,nz+Math.sin(a)*r,.37,.055,.12,k%2?straw:twigLight);
}
const eggCount=Math.min(5,1+Math.floor(growth/2));
for(let k=0;k<eggCount;k++){
 const a=k*Math.PI*2/eggCount;
 box(nx+Math.cos(a)*.44,.54,nz+Math.sin(a)*.44,.27,.32,.34,k%2?[.92,.92,.83]:[.98,.94,.80]);
}
// Upgrades add leaves, flowers, feathers and a tiny purple flock pennant.
if(nestLevel>=3){
 for(let k=0;k<8+growth*2;k++){
  const a=k*2.4,r=outer+.10;
  box(nx+Math.cos(a)*r,.28,nz+Math.sin(a)*r,.31,.10,.48,k%3?[.38,.59,.28]:[.54,.73,.35]);
 }
}
if(nestLevel>=5){
 for(let k=0;k<5+Math.min(growth,5);k++){
  const a=k*Math.PI*2/(5+Math.min(growth,5)),r=outer+.26;
  box(nx+Math.cos(a)*r,.34,nz+Math.sin(a)*r,.16,.30,.16,k%2?[.88,.55,.75]:[.94,.82,.34]);
  box(nx+Math.cos(a)*r,.60,nz+Math.sin(a)*r,.22,.12,.22,k%2?[.84,.42,.68]:[.95,.84,.42]);
 }
 for(let k=0;k<5;k++){
  const a=k*Math.PI*2/5;
  box(nx+Math.cos(a)*(outer-.12),.68,nz+Math.sin(a)*(outer-.12),.12,.32,.19,[.85,.88,.93]);
 }
}
if(nestLevel>=7){
 // Small ceremonial banner attached beside the nest; no walls or roof.
 const fx=nx+outer+.39,fz=nz-.40;
 box(fx,.16,fz,.10,2.10,.10,[.55,.34,.19]);
 box(fx+.23,1.64,fz,.52,.53,.10,[.45,.25,.64]);
 box(fx+.16,1.78,fz+.06,.18,.18,.05,[.94,.91,.76]);
}
pigeon(nx,nz,1,0,Math.min(1.3,.9+nestLevel*.07));
placeBounds.push({x:nx,z:nz,h:2.4,w:8,d:8,nest:true});
// Four visible and individually tappable headquarters buildings. Each one grows
// in height, detail and decoration with its actual saved upgrade level.
const hqLevels=window.pigeonBuildingLevels?.()||[0,0,0,0];
const workshops=[
 {x:-27,z:9,name:'Futterlager',colors:[[.80,.62,.36],[.58,.35,.17]]},
 {x:-27,z:18,name:'Brutstation',colors:[[.94,.82,.57],[.79,.48,.35]]},
 {x:-11,z:11,name:'Expeditionsbüro',colors:[[.45,.72,.71],[.24,.48,.58]]},
 {x:-11,z:25,name:'Federwerkstatt',colors:[[.73,.62,.85],[.44,.35,.66]]}
];
workshops.forEach((w,id)=>{
 const level=Math.max(0,Math.min(10,Number(hqLevels[id])||0)),tier=Math.min(4,Math.floor(level/2));
 const x=w.x,z=w.z,base=w.colors[0],accent=w.colors[1];
 // Small working structures (not nests), increasingly ornate as they improve.
 box(x,0,z,5.5,.15,5.5,[.65,.70,.58]);
 const height=1.6+tier*.65;
 box(x,.15,z,3.5+tier*.34,height,3.4+tier*.25,base);
 box(x,.15+height,z,4.2+tier*.35,.30,4.1+tier*.3,accent);
 box(x,.25,z+1.8+tier*.12,1.2,1.2,.15,[.35,.28,.22]);
 // Windows, work surfaces, and increasingly numerous upgrades.
 for(let k=0;k<Math.min(4,1+tier);k++){
  box(x-1.3+k*.85,1.1,z+1.85+tier*.12,.42,.52,.13,[.80,.93,.94]);
 }
 if(id===0){ // grain bins and golden feed crates
  for(let k=0;k<1+tier;k++)box(x-2.5+k*.5,.2,z-1.7,.55,.65+tier*.14,.65,[.86,.68,.30]);
 }else if(id===1){ // warm incubator dome, eggs and copper pipes
  box(x,.45+height,z,1.7+tier*.2,.55+tier*.13,1.7+tier*.2,[.97,.88,.67]);
  for(let k=0;k<1+tier;k++)box(x-1+k*.6,.25,z+2.2,.38,.45,.35,[.98,.96,.83]);
 }else if(id===2){ // map lookout and banner
  box(x+1.2,.45+height,z,.16,1.1+tier*.3,.16,[.50,.34,.22]);
  box(x+1.6,1.25+height,z,.78,.52,.12,[.28,.72,.62]);
 }else{ // feather spools and colorful feathers
  for(let k=0;k<1+tier;k++)box(x-1.5+k*.7,.25,z+2.15,.28,1.0+tier*.15,.30,k%2?[.93,.79,.94]:[.87,.92,.99]);
 }
 if(level>=5)for(let k=0;k<4;k++)box(x+(k%2?2.2:-2.2),.2,z+(k<2?1.9:-1.9),.28,.65,.28,accent);
 placeBounds.push({x,z,h:height+2.6,w:6.2,d:6.2,buildingId:id});
});
// distant unbuilt areas for later expansion
for(const [x,z] of [[19,-19],[19,19]]){box(x,0,z,9,.08,9,[.49,.7,.47]);for(let k=0;k<5;k++)tree(x-3+k*1.3,z+2,.8)}
}
function perspective(p,w,h){const {yaw,pitch,dist,cx,cz}=camera;const eye=[cx+Math.sin(yaw)*Math.cos(pitch)*dist,Math.sin(pitch)*dist,cz+Math.cos(yaw)*Math.cos(pitch)*dist];let f=[cx-eye[0],-eye[1],cz-eye[2]];const len=Math.hypot(...f);f=f.map(v=>v/len);let right=[-f[2],0,f[0]];let up=[right[1]*f[2]-right[2]*f[1],right[2]*f[0]-right[0]*f[2],right[0]*f[1]-right[1]*f[0]];const v=p.map((q,i)=>q-eye[i]),X=v.reduce((a,q,i)=>a+q*right[i],0),Y=v.reduce((a,q,i)=>a+q*up[i],0),Z=v.reduce((a,q,i)=>a+q*f[i],0);const aspect=w/h,t=Math.tan(.62/2);return [X/(Math.max(.1,Z)*t*aspect),Y/(Math.max(.1,Z)*t),Z];}
function shader(type,source){const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s}
function setup(){canvas=document.getElementById('three-city');if(!canvas)return;gl=canvas.getContext('webgl',{antialias:true,alpha:false});if(!gl){canvas.replaceWith(Object.assign(document.createElement('p'),{textContent:'3D benötigt WebGL. Bitte Hardwarebeschleunigung in Chrome aktivieren.'}));return;}program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,'attribute vec3 p;attribute vec3 c;varying vec3 color;void main(){gl_Position=vec4(p,1.0);color=c;}'));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,'precision mediump float;varying vec3 color;void main(){gl_FragColor=vec4(color,1.0);}'));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('WebGL link failed');gl.useProgram(program);buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);for(const [name] of [['p'],['c']]){const a=gl.getAttribLocation(program,name);gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,3,gl.FLOAT,false,24,name==='p'?0:12)}gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.clearColor(.64,.83,.91,1);makeScene();staticVerts=verts.slice();events();draw()}
// Each citizen follows a different rectangular sidewalk route, turning at corners.
// Routes are spaced and phased so NPCs do not form overlapping single-file trains.
const pedestrianRoutes=[
 [[-22,-21],[-6,-21],[-6,-14],[-22,-14]],
 [[-5,-22],[6,-22],[6,-13],[-5,-13]],
 [[10,-22],[23,-22],[23,-13],[10,-13]],
 [[-22,-11],[-14,-11],[-14,5],[-22,5]],
 [[-11,-10],[5,-10],[5,-5],[-11,-5]],
 [[10,-10],[22,-10],[22,-5],[10,-5]],
 [[-22,9],[-14,9],[-14,22],[-22,22]],
 [[-11,9],[5,9],[5,14],[-11,14]],
 [[10,9],[22,9],[22,14],[10,14]],
 [[-11,17],[5,17],[5,23],[-11,23]],
 [[10,17],[23,17],[23,23],[10,23]],
 [[-22,-4],[-22,5],[-14,5],[-14,-4]]
];
const pigeonRoutes=[
 [[-24,-24],[-12,-22],[-8,-11],[-21,-7]],
 [[-3,-24],[9,-20],[7,-10],[-5,-8]],
 [[12,-24],[24,-20],[20,-9],[9,-11]],
 [[-24,8],[-9,7],[-7,20],[-23,23]],
 [[-4,7],[8,10],[7,24],[-7,22]],
 [[12,6],[24,9],[22,24],[9,20]],
 [[-22,-6],[-10,-4],[-11,7],[-23,6]],
 [[-4,-5],[8,-3],[7,7],[-6,5]]
];
// Closed Catmull-Rom splines round corners smoothly and provide a tangent for facing.
function smoothPoint(route,distance){
 const n=route.length,steps=16,samples=[];let total=0;
 function point(k,u){
  const p0=route[(k-1+n)%n],p1=route[k],p2=route[(k+1)%n],p3=route[(k+2)%n];
  const f=(a,b,c,d)=>.5*((2*b)+(-a+c)*u+(2*a-5*b+4*c-d)*u*u+(-a+3*b-3*c+d)*u*u*u);
  return [f(p0[0],p1[0],p2[0],p3[0]),f(p0[1],p1[1],p2[1],p3[1])];
 }
 let prev=point(0,0);samples.push({p:prev,d:0});
 for(let k=0;k<n;k++)for(let j=1;j<=steps;j++){
  const p=point(k,j/steps);total+=Math.hypot(p[0]-prev[0],p[1]-prev[1]);samples.push({p,d:total});prev=p;
 }
 const pos=((distance%total)+total)%total;
 let lo=0,hi=samples.length-1;
 while(lo+1<hi){const m=(lo+hi)>>1;if(samples[m].d<pos)lo=m;else hi=m;}
 const a=samples[lo],b=samples[hi],u=(pos-a.d)/Math.max(.00001,b.d-a.d);
 return [a.p[0]+(b.p[0]-a.p[0])*u,a.p[1]+(b.p[1]-a.p[1])*u];
}
function headingAt(route,d,dir){
 const p=smoothPoint(route,d),q=smoothPoint(route,d+dir*.18);
 return Math.atan2(-(q[0]-p[0]),-(q[1]-p[1]));
}
function draw(){if(!canvas?.isConnected)return;
 const tick=Math.floor(performance.now()/50);
 if(tick!==lastPeopleTick){lastPeopleTick=tick;verts=staticVerts.slice();const t=performance.now()/1000;
  pedestrians=[];
  for(let i=0;i<19;i++){
   const route=pedestrianRoutes[i%pedestrianRoutes.length];
   const speed=.42+(i%5)*.085,dir=i%2?-1:1;
   const offset=i*13.7+Math.floor(i/pedestrianRoutes.length)*19;
   const d=offset+t*speed*dir,[x,z]=smoothPoint(route,d);
   pedestrians.push({x,z,id:i});
   const r=attack&&attack.hit&&attack.target===i?{kind:attack.reaction,elapsed:t-attack.hitTime}:null;
   let px=x,pz=z,face=headingAt(route,d,dir),walkSpeed=speed;
   if(r&&r.elapsed>=0&&r.elapsed<3.3){
    if(r.kind===2){ // flee sideways from the impact, then return to normal route
     const run=Math.sin(Math.min(1,r.elapsed/2.8)*Math.PI)*2.3;
     px+=Math.sin(face+Math.PI/2)*run;pz+=Math.cos(face+Math.PI/2)*run;
     face+=Math.PI/2;walkSpeed=2.3;
    }else if(r.kind===3){walkSpeed=0;face+=Math.sin(r.elapsed*3.3)*.3;}
    else if(r.kind===1){face+=Math.sin(r.elapsed*7)*.3;walkSpeed=0;}
    else if(r.kind===0){walkSpeed=0;}
   }
   person(px,pz,i,t,face,walkSpeed,r);
   pedestrians[i]={x:px,z:pz,id:i};
  }
  for(let i=0;i<12;i++){
   const route=pigeonRoutes[i%pigeonRoutes.length];
   const speed=.55+(i%4)*.18,dir=i%3===0?-1:1;
   const d=i*11.3+t*speed*dir;
   const [x,z]=smoothPoint(route,d);
   // Individual flight cycles: take off, climb, bank, glide, descend and land.
   const phase=(t*.115+i*.217)%1;
   const flight=Math.max(0,Math.min(1,(phase-.12)/.15,(.92-phase)/.18));
   const flying=flight>.05;
   const altitude=flight*(1.3+(i%4)*.6)+Math.sin(t*2+i)*.06*flight;
   const heading=headingAt(route,d,dir);
   pigeon(x,z,t,heading,Math.max(.02,altitude),flying,i);
  }
  if(selectedHuman>=0&&pedestrians[selectedHuman]){
   const h=pedestrians[selectedHuman];
   box(h.x,1.75,h.z,.65,.10,.65,[1,.83,.16]);
  }
  if(attack){
   const age=t-attack.start,target=pedestrians[attack.target];
   if(target){
    const hitAt=2.3,exitDuration=3.1;
    const u=clamp(age/hitAt,0,1),ease=u*u*(3-2*u);
    // Lock the hit position once reached; fly onwards instead of vanishing above the target.
    if(age>=hitAt&&!attack.hit){
     attack.hit=true;attack.hitTime=t;attack.hitX=target.x;attack.hitZ=target.z;
     attack.exitDir=[target.x-attack.from[0],target.z-attack.from[1]];
     const len=Math.hypot(...attack.exitDir)||1;attack.exitDir=attack.exitDir.map(v=>v/len);
     window.pigeonAttackComplete?.(attack.target,attack.reaction);
    }
    let x,z,y,heading;
    if(age<hitAt){
     x=attack.from[0]*(1-ease)+target.x*ease+Math.sin(u*Math.PI)*2.5;
     z=attack.from[1]*(1-ease)+target.z*ease-Math.sin(u*Math.PI)*1.7;
     y=2.5+Math.sin(u*Math.PI)*2.5;
     const du=.015,v=clamp(u+du,0,1),e2=v*v*(3-2*v);
     const nx=attack.from[0]*(1-e2)+target.x*e2+Math.sin(v*Math.PI)*2.5;
     const nz=attack.from[1]*(1-e2)+target.z*e2-Math.sin(v*Math.PI)*1.7;
     heading=Math.atan2(-(nx-x),-(nz-z));
    }else{
     const out=age-hitAt,dir=attack.exitDir;
     // Smooth accelerating exit, with a wide turn and rising altitude.
     const travel=out*7.8+out*out*2.3;
     const side=Math.sin(Math.min(1,out/exitDuration)*Math.PI)*3.4;
     x=attack.hitX+dir[0]*travel-dir[1]*side;
     z=attack.hitZ+dir[1]*travel+dir[0]*side;
     y=2.5+Math.min(out*1.7,5.1);
     const next=out+.02,nextTravel=next*7.8+next*next*2.3;
     const nextSide=Math.sin(Math.min(1,next/exitDuration)*Math.PI)*3.4;
     const nx=attack.hitX+dir[0]*nextTravel-dir[1]*nextSide;
     const nz=attack.hitZ+dir[1]*nextTravel+dir[0]*nextSide;
     heading=Math.atan2(-(nx-x),-(nz-z));
    }
    if(age<hitAt+exitDuration)pigeon(x,z,t,heading,y,true,25);
    if(age>1.65&&age<2.65){
     const drop=clamp((age-1.65)/.65,0,1);
     box(attack.hit?attack.hitX:target.x,Math.max(.04,2.8*(1-drop)),attack.hit?attack.hitZ:target.z,.15,.14,.15,[.97,.97,.88]);
    }
    if(age>hitAt+exitDuration)attack=null;
   }else attack=null;
  }
 }
const w=Math.max(1,Math.round(canvas.clientWidth*devicePixelRatio)),h=Math.max(1,Math.round(canvas.clientHeight*devicePixelRatio));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;gl.viewport(0,0,w,h)}const data=new Float32Array(verts.length);for(let i=0;i<verts.length;i+=6){const [x,y,z]=perspective(verts.slice(i,i+3),w,h);data[i]=x;data[i+1]=y;data[i+2]=clamp((z-1)/120*2-1,-.99,.99);data.set(verts.slice(i+3,i+6),i+3)}gl.bufferData(gl.ARRAY_BUFFER,data,gl.STATIC_DRAW);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.drawArrays(gl.TRIANGLES,0,data.length/6);frame=requestAnimationFrame(draw)}
function events(){
 const pointers=new Map();let gesture=null,moved=false,multiTouch=false,tapOrigin=null;
 const clampDelta=(n,limit)=>clamp(n,-limit,limit);
 const pair=()=>{const a=[...pointers.values()];if(a.length!==2)return null;const dx=a[1][0]-a[0][0],dy=a[1][1]-a[0][1];return {midX:(a[0][0]+a[1][0])/2,midY:(a[0][1]+a[1][1])/2,angle:Math.atan2(dy,dx),distance:Math.max(1,Math.hypot(dx,dy))};};
 const normalizeAngle=a=>Math.atan2(Math.sin(a),Math.cos(a));
 canvas.addEventListener('pointerdown',e=>{
  e.preventDefault();canvas.setPointerCapture(e.pointerId);
  pointers.set(e.pointerId,[e.clientX,e.clientY]);
  if(pointers.size===1){moved=false;multiTouch=false;gesture=null;tapOrigin=[e.clientX,e.clientY];}
  else {multiTouch=true;moved=true;gesture=pair();tapOrigin=null;}
 });
 canvas.addEventListener('pointermove',e=>{
  if(!pointers.has(e.pointerId))return;
  e.preventDefault();const old=pointers.get(e.pointerId);
  pointers.set(e.pointerId,[e.clientX,e.clientY]);
  const dx=e.clientX-old[0],dy=e.clientY-old[1];
  if(tapOrigin&&Math.hypot(e.clientX-tapOrigin[0],e.clientY-tapOrigin[1])>8)moved=true;
  if(pointers.size===1){
   // Deliberately gentle panning, adjusted for distance and viewport size.
   const scale=camera.dist*.0038;
   camera.cx+=(-dx*Math.cos(camera.yaw)+dy*Math.sin(camera.yaw))*scale;
   camera.cz+=(dx*Math.sin(camera.yaw)+dy*Math.cos(camera.yaw))*scale;
   camera.cx=clamp(camera.cx,-36,36);camera.cz=clamp(camera.cz,-36,36);
  }else if(pointers.size===2){
   // Rotate using the actual change in the angle BETWEEN fingers.
   // This avoids the previous midpoint-based wobble when fingers move differently.
   const now=pair();
   if(gesture&&now){
    const twist=normalizeAngle(now.angle-gesture.angle);
    if(Math.abs(twist)>.002)camera.yaw-=clampDelta(twist, .12)*1.15;
    // Vertical two-finger movement tilts only gently, without affecting yaw.
    const vertical=clampDelta(now.midY-gesture.midY,16);
    if(Math.abs(vertical)>1.5)camera.pitch=clamp(camera.pitch+vertical*.0025,.28,1.4);
    const ratio=clamp(now.distance/gesture.distance,.92,1.08);
    if(Math.abs(now.distance-gesture.distance)>1.2)camera.dist=clamp(camera.dist/ratio,12,100);
   }
   gesture=now;
  }
 });
 canvas.addEventListener('pointerup',e=>{
  const wasTap=!moved&&!multiTouch&&pointers.size===1;
  pointers.delete(e.pointerId);gesture=pair();
  if(pointers.size===0){multiTouch=false;tapOrigin=null;}
  else {multiTouch=true;tapOrigin=null;}
  if(!wasTap)return;
  const rect=canvas.getBoundingClientRect(),mx=((e.clientX-rect.left)/rect.width)*2-1,my=1-((e.clientY-rect.top)/rect.height)*2;
  // In air-raid mode a tap chooses a moving pedestrian, not a building.
  if(attackMode){
   let closest=-1,best=Infinity;
   pedestrians.forEach((h,i)=>{
    const pt=perspective([h.x,.95,h.z],canvas.width,canvas.height);
    const dist=Math.hypot((pt[0]-mx)*rect.width/2,(pt[1]-my)*rect.height/2);
    if(pt[2]>0&&dist<Math.max(34,1300/pt[2])&&dist<best){best=dist;closest=i;}
   });
   if(closest>=0){selectedHuman=closest;attackMode=false;window.pigeonHumanSelected?.(closest);}
   return;
  }
  // Pick against the projected silhouette of the WHOLE landmark, not its tiny roof marker.
  // Include a modest touch allowance for mobile fingers, and choose the closest visible landmark.
  let nearest=-1,nearestDepth=Infinity;
  placeBounds.forEach((b,i)=>{
   const corners=[];
   for(const xx of [-b.w/2,b.w/2])for(const yy of [0,b.h])for(const zz of [-b.d/2,b.d/2]){
    const pt=perspective([b.x+xx,yy,b.z+zz],canvas.width,canvas.height);
    if(pt[2]>0)corners.push(pt);
   }
   if(!corners.length)return;
   const padX=24/rect.width*2,padY=24/rect.height*2;
   const minX=Math.min(...corners.map(v=>v[0]))-padX,maxX=Math.max(...corners.map(v=>v[0]))+padX;
   const minY=Math.min(...corners.map(v=>v[1]))-padY,maxY=Math.max(...corners.map(v=>v[1]))+padY;
   if(mx>=minX&&mx<=maxX&&my>=minY&&my<=maxY){
    const depth=perspective([b.x,b.h/2,b.z],canvas.width,canvas.height)[2];
    if(depth<nearestDepth){nearestDepth=depth;nearest=i;}
   }
  });
  if(nearest>=0&&placeBounds[nearest]?.nest){window.pigeonOpenNest?.();return;}
  if(nearest>=0&&Number.isInteger(placeBounds[nearest]?.buildingId)){window.pigeonOpenBuilding?.(placeBounds[nearest].buildingId);return;}
  if(nearest>=0&&nearest<8){selectedPlace=nearest;render();const detail=document.getElementById('place-detail');if(detail)detail.scrollIntoView({behavior:'smooth',block:'nearest'});}
 });
 canvas.addEventListener('pointercancel',e=>{pointers.delete(e.pointerId);gesture=pair();tapOrigin=null;multiTouch=pointers.size>0;});
 canvas.addEventListener('wheel',e=>{e.preventDefault();camera.dist=clamp(camera.dist*(e.deltaY>0?1.12:.88),12,100)},{passive:false});
}
window.pigeonAttackRunning=()=>!!attack;
window.pigeonSelectHuman=()=>{attackMode=true;selectedHuman=-1;};
window.pigeonCancelSelect=()=>{attackMode=false;selectedHuman=-1;};
window.pigeonStartAttack=(id)=>{
 if(attack||!pedestrians[id])return false;
 const h=pedestrians[id];attack={target:id,from:[h.x-9,h.z-8],start:performance.now()/1000,hit:false,reaction:id%4};
 selectedHuman=-1;attackMode=false;return true;
};
window.initCity3D=()=>{if(frame)cancelAnimationFrame(frame);try{setup()}catch(e){console.error('3D:',e);const c=document.getElementById('three-city');if(c)c.replaceWith(Object.assign(document.createElement('p'),{textContent:'3D konnte nicht gestartet werden: '+e.message}));}};
window.cityZoom=d=>{camera.dist=clamp(camera.dist*(d>0?1.2:.83),12,100)};
window.cityReset=()=>{camera={yaw:.65,pitch:.88,dist:40,cx:0,cz:0}};
})();
